# Priya & Raj — Engagement Invitation

A responsive engagement invitation website for Priya & Raj.

## Run locally

Open `index.html` in a browser.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html` and the `assets` folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save and open the generated GitHub Pages URL.

The page uses only HTML, CSS, JavaScript, local images, and local audio.
